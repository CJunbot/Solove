import json
from collections import OrderedDict

with open('1.json','r') as f:
    s = f.read()
    s = s.replace('\t','')
    s = s.replace('\n','')
    s = s.replace(',}','}')
    s = s.replace(',]',']')
    data = json.loads(s)

    dict=data

    dna = dict['dna']

    print(dna)
    
