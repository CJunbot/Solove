import json
from collections import OrderedDict


for i in range(1, 101):
    j = str(i)
    with open(j+'.json','r') as f:
        #파일 읽어서 홑따옴표같은 병신 제거
        s = f.read()
        s = s.replace('\t','')
        s = s.replace('\n','')
        s = s.replace(',}','}')
        s = s.replace(',]',']')
        data = json.loads(s)

        #딕셔너리 변경
        dict=data

        dict['seller_fee_basis_points']=500
        dict['symbol']="hi"
        dna = str(dict['dna'])
        dict2={"address": "{dna}" .format(dna=dna), "share": 100}
        dict3={"uri": "{i}.png".format(i=i), "type": "image/png"}
        dict['image'] = ["{i}.png" .format(i=i)]
        list1=[]
        list2=[]
        list1.append(dict2)
        list2.append(dict3)

        value1={"creators":list1,"files":list2}
        value3={"name": "numbers", "family": "numbers"}
        dict['properties']=value1
        dict['collection']=value3
        dict['attributes']={"class": "unrevealed"}

        od=OrderedDict()
        od['name']=dict['name']
        od['symbol']=dict['symbol']
        od['description']=dict['description']
        od['seller_fee_basis_points']= dict['seller_fee_basis_points']

        od['image']=dict['image']
        od['attributes']=dict['attributes']
        od['properties']=dict['properties']
        od['collection']=dict['collection']



    #파일에 다시 쓰기
    with open(j+'.json', "w") as json_file:
        json.dump(od, json_file,indent=4)